package OliverPOS.Oliver;

import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

import Utilities.ConfigProvider;
import Utilities.FileHandlers;

public class TC001 {
OliverHomePO home = new OliverHomePO("Chrome");	
String path = System.getProperty("user.dir")+"\\src\\resources";
String FileName = "OliverTestData.xlsx";
@Test
public void loginFunction() throws InvalidFormatException {
	home.navigateToUrl(ConfigProvider.configFileReader("ApplicationUrl"));
	Map<String,String> login = FileHandlers.readExcel(path, FileName, "Login", "TC001");
	home.login(login.get("User"),login.get("Password"));
	home.selectRegister();
	home.enterPin(login.get("Pin"));
	Map<String,String> input = FileHandlers.readExcel(path, FileName, "Input", "TC001");
	home.addCustomer(input);
}
	
}
