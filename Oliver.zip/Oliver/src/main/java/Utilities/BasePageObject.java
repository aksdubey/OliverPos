package Utilities;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePageObject {

	protected static WebDriver driver;

	public BasePageObject() {
		WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(500, TimeUnit.SECONDS);

	}

	public BasePageObject(String BrowserName) {

		if (BrowserName.equalsIgnoreCase("Chrome")) {
			WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
			driver = new ChromeDriver();
		}
		else if(BrowserName.equalsIgnoreCase("Firefox")) {
			WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
			driver = new FirefoxDriver();
		}else {
			WebDriverManager.getInstance(DriverManagerType.CHROME).setup();
			driver = new InternetExplorerDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.manage().timeouts().pageLoadTimeout(500, TimeUnit.SECONDS);
	}
	
	public void navigateToUrl(String Url) {
		driver.navigate().to(Url);
	}
	
	public  void quit() {
		driver.quit();
	}
	
	public static WebElement getElementSafely(By path) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		 .withTimeout(240, TimeUnit.SECONDS)
         .pollingEvery(5, TimeUnit.SECONDS)
         .ignoring(NoSuchElementException.class);	
		WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(path));
		return el;
	}
	
	public static void clickElementSafely(By path)
	{
		 FluentWait<WebDriver> ClickableWait = new FluentWait<WebDriver>(driver)
		            .withTimeout(240, TimeUnit.SECONDS)
		            .pollingEvery(5, TimeUnit.SECONDS)
		            .ignoring(NoSuchElementException.class);
		 
	WebElement el =	 ClickableWait.until(ExpectedConditions.elementToBeClickable(driver.findElement(path)));
	el.click();
	}
	
	public void clickElementSafely(By path,long timeoutInSeconds)
	{
		 FluentWait<WebDriver> ClickableWait = new FluentWait<WebDriver>(driver)
		            .withTimeout(timeoutInSeconds, TimeUnit.SECONDS)
		            .pollingEvery(5, TimeUnit.SECONDS)
		            .ignoring(NoSuchElementException.class);
		 
	WebElement el =	 ClickableWait.until(ExpectedConditions.elementToBeClickable(driver.findElement(path)));
	el.click();
	}
	
	public static void clickElementByText(String text) {
		clickElementSafely(By.xpath("//button[contains(text(),'"+text+"')]"));
	}
}
