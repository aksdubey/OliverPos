package OliverPOS.Oliver;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utilities.BasePageObject;

public class OliverHomePO extends BasePageObject {
public OliverHomePO() {
	super();
}
public OliverHomePO(String BrowserName) {
	super(BrowserName);
}
	private enum FIELD{
		Login_User(By.id("username")),
		Login_Password(By.id("password")),
		Login_Button(By.xpath("//button[contains(text(),'Login')]")),
		Login_Register(By.xpath("(//ul[contains(@class,'list-group chooseregisterLinks')]/li/a)[1]")),
		Link_CustomerView(By.xpath("//a[contains(text(),'Customer View')]")),
		Add_Cust_FName(By.name("cust_fname")),
		Add_Cust_LName(By.name("cust_lname")),
		Add_Cust_Email(By.name("cust_email")),
		Add_Cust_Phone(By.name("cust_phone_number")),
		Add_Cust_Street(By.name("cust_street_address")),
		Add_Cust_City(By.name("cust_city")),
		Add_Cust_Zip(By.name("cust_postcode")),
		;
		private By findby;
		private FIELD(By findby) {
			this.findby = findby;
		}
	}

	public void login(String User,String Password) {
		getElementSafely(FIELD.Login_User.findby).sendKeys(User);
		getElementSafely(FIELD.Login_Password.findby).sendKeys(Password);
		clickElementSafely(FIELD.Login_Button.findby);
	}
	
	public void selectRegister() {
		
    	try {
    		Thread.sleep(2000);
    		clickElementSafely(FIELD.Login_Register.findby);
			Thread.sleep(2000);
			clickElementSafely(FIELD.Login_Register.findby);
	    	Thread.sleep(2000);
	    	clickElementSafely(FIELD.Login_Register.findby);
	    	Thread.sleep(2000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
	}
	
	
	public void enterPin(String pin) {
		
		for(int i=0;i<pin.length();i++) {
		char St = pin.charAt(i); 
		clickElementSafely(By.xpath("//input[@id='keys' and @value='"+St+"']"));
		}
	}
	
	public void addCustomer(Map<String,String> input) {
		clickElementSafely(FIELD.Link_CustomerView.findby);
		try {
			Thread.sleep(3000);
			clickElementByText("CREATE NEW CUSTOMER");
			getElementSafely(FIELD.Add_Cust_FName.findby).sendKeys(input.get("FirstNane"));
			getElementSafely(FIELD.Add_Cust_LName.findby).sendKeys(input.get("LastName"));
			getElementSafely(FIELD.Add_Cust_Email.findby).sendKeys(input.get("Email"));
			getElementSafely(FIELD.Add_Cust_Phone.findby).sendKeys(input.get("Phone"));
			getElementSafely(FIELD.Add_Cust_Street.findby).sendKeys(input.get("Street"));
			getElementSafely(FIELD.Add_Cust_City.findby).sendKeys(input.get("City"));
			getElementSafely(FIELD.Add_Cust_Zip.findby).sendKeys(input.get("Zip"));
			clickElementSafely(By.xpath("//div[@id='create-customer']//button[contains(text(),'SAVE & UPDATE')]"));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
