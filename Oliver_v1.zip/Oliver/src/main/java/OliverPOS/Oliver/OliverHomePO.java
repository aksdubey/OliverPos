package OliverPOS.Oliver;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Utilities.BasePageObject;

public class OliverHomePO extends BasePageObject {
	public OliverHomePO() {
		super();
	}

	public OliverHomePO(String BrowserName) {
		super(BrowserName);
	}

	private By Login_User = By.id("username");
	private By Login_Password = By.id("password");
	private By Login_Button = By.xpath("//button[contains(text(),'Login')]");
	private By Login_Register = By.xpath("(//ul[contains(@class,'list-group chooseregisterLinks')]/li/a)[1]");
	private By Link_CustomerView = By.xpath("//a[contains(text(),'Customer View')]");
	private By Add_Cust_FName = By.name("cust_fname");
	private By Add_Cust_LName = By.name("cust_lname");
	private By Add_Cust_Email = By.name("cust_email");

	private By Add_Cust_Phone = By.name("cust_phone_number");
	private By Add_Cust_Street = By.name("cust_street_address");
	private By Add_Cust_City = By.name("cust_city");
	private By Add_Cust_Zip = By.name("cust_postcode");;


	public void login(String User, String Password) {
		getElementSafely(Login_User).sendKeys(User);
		getElementSafely(Login_Password).sendKeys(Password);
		clickElementSafely(Login_Button);
	}

	public void selectRegister() {

		try {
			Thread.sleep(2000);
			clickElementSafely(Login_Register);
			Thread.sleep(2000);
			clickElementSafely(Login_Register);
			Thread.sleep(2000);
			clickElementSafely(Login_Register);
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void enterPin(String pin) {

		for (int i = 0; i < pin.length(); i++) {
			char St = pin.charAt(i);
			clickElementSafely(By.xpath("//input[@id='keys' and @value='" + St + "']"));
		}
	}

	public void addCustomer(Map<String, String> input) {
		clickElementSafely(Link_CustomerView);
		try {
			Thread.sleep(3000);
			clickElementByText("CREATE NEW CUSTOMER");
			getElementSafely(Add_Cust_FName).sendKeys(input.get("FirstNane"));
			getElementSafely(Add_Cust_LName).sendKeys(input.get("LastName"));
			getElementSafely(Add_Cust_Email).sendKeys(input.get("Email"));
			getElementSafely(Add_Cust_Phone).sendKeys(input.get("Phone"));
			getElementSafely(Add_Cust_Street).sendKeys(input.get("Street"));
			getElementSafely(Add_Cust_City).sendKeys(input.get("City"));
			getElementSafely(Add_Cust_Zip).sendKeys(input.get("Zip"));
			clickElementSafely(By.xpath("//div[@id='create-customer']//button[contains(text(),'SAVE & UPDATE')]"));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
